#!/usr/bin/env bash
set -e
ROOT="$(cd "$(dirname "$0")" && pwd)"
echo "BLUEsky OS build scaffold"
echo "AOSP source is intentionally not bundled. Add your AOSP checkout and device tree."
echo "UI preview: $ROOT/apps/BlueHome/index.html"
