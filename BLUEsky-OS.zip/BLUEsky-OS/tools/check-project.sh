#!/usr/bin/env bash
set -e
for f in README.md build.sh apps/BlueHome/index.html apps/BlueHome/style.css apps/BlueHome/script.js; do test -f "$f" && echo "OK $f"; done
echo "Scaffold check complete."
