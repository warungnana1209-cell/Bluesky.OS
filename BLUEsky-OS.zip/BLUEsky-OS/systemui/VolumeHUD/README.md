# VolumeHUD
Native Android/SystemUI component specification for BLUEsky OS.
Implement with Kotlin/Java and Android framework APIs when integrating into AOSP.
