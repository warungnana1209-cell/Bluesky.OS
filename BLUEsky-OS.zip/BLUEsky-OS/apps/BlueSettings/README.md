# BlueSettings
Native Android implementation target: build this feature set as an Android Settings module/SystemUI integration.
Planned categories: Network, Display, Sound, Notifications, Apps, Battery, Storage, Privacy, Security, System, About BLUEsky OS.
