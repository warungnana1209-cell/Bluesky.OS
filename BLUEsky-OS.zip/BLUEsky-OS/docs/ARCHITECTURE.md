# Architecture
AOSP base -> Android Framework -> SystemUI/Launcher -> BLUEsky components -> device/vendor/kernel.

The bundled web preview is only a visual prototype. It is not Android SystemUI and cannot be flashed as a ROM.
