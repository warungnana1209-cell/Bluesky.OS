# Device configuration placeholder. Replace with a real target device tree.
PRODUCT_NAME := bluesky
PRODUCT_BRAND := BLUEsky
PRODUCT_MODEL := BLUEsky OS Reference Device
