# BLUEsky OS
AOSP-oriented Android OS project scaffold with an original glass/futuristic UI inspired by modern mobile design.

This is a development scaffold, not a flashable ROM. Device-specific kernel, vendor blobs, device tree, signing keys, and AOSP source are required for a bootable build.

## Build UI demo
Open `apps/BlueHome/index.html` in a browser or SPCK Editor.

## Native roadmap
- Integrate BlueHome concepts into Android Launcher3/SystemUI.
- Add device tree/vendor/kernel for a target device.
- Build with AOSP/Android build tools on Linux.
